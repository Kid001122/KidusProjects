package com.example.time_manager_mobile_app

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class HomePage : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home_page)

        var CPC = findViewById<Button>(R.id.createbtn)
        CPC.setOnClickListener {

            startActivity(Intent(this, CategoryCreation::class.java))
            finish()


        }
        var CPT = findViewById<Button>(R.id.createtask)
        CPT.setOnClickListener {

            startActivity(Intent(this, Task_Creation::class.java))
            finish()


        }
    }
}