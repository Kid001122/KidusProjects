package com.example.time_manager_mobile_app

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class CategoryCreation : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_category_creation)

    }
}