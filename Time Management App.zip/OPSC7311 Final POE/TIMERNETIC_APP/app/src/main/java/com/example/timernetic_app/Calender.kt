package com.example.timernetic_app

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.CalendarView
import android.widget.CalendarView.OnDateChangeListener
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.database.*

class Calender : AppCompatActivity() {
    private var calendarView: CalendarView? = null
    private var editText: EditText? = null
    private var selectedDate: String? = null
    private var databaseReference: DatabaseReference? = null
    private var backButton: Button? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_calender)

        calendarView = findViewById(R.id.calendarView)
        editText = findViewById(R.id.editText)
        backButton = findViewById(R.id.backtomenu1)

        databaseReference = FirebaseDatabase.getInstance().getReference("Calendar")

        calendarView?.setOnDateChangeListener { _, year, month, dayOfMonth ->
            selectedDate = year.toString() + (month + 1).toString() + dayOfMonth.toString()
            calendarClicked()
        }

        backButton?.setOnClickListener {
            startActivity(Intent(this, MainActivity::class.java))
            finish()
        }

        val buttonSave: Button = findViewById(R.id.buttonSave)
        buttonSave.setOnClickListener {
            buttonSaveEvent()
        }
    }

    private fun calendarClicked() {
        selectedDate?.let { date ->
            databaseReference?.child(date)
                ?.addListenerForSingleValueEvent(object : ValueEventListener {
                    override fun onDataChange(snapshot: DataSnapshot) {
                        if (snapshot.value != null) {
                            editText?.setText(snapshot.value.toString())
                        } else {
                            editText?.setText("No event on this day")
                        }
                    }

                    override fun onCancelled(error: DatabaseError) {
                        // Handle the onCancelled event if needed
                    }
                })
        }
    }

    private fun buttonSaveEvent() {
        val eventText = editText?.text.toString()
        selectedDate?.let { date ->
            databaseReference?.child(date)?.setValue(eventText)?.addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    Toast.makeText(this, "Event saved successfully", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this, "Failed to save event", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }
}