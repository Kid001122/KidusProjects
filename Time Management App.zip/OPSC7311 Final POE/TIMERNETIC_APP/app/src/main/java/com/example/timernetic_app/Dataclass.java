package com.example.timernetic_app;

public class Dataclass {
    private String dataTitle;
    private String dataDesc;
    private String dataLang;
    private String dataImage;
    private String dateEnd;
    private String MinGoal;
    private String MaxGoal;
    private String TaskName;
    private String Key;
    public String getKey(){
        return Key;
    }

    public void setKey(String Key){
        this.Key=Key;
    }


    public String getDataTitle() {
        return dataTitle;
    }

    public String getDataDesc() {
        return dataDesc;
    }

    public String getDataLang() {
        return dataLang;
    }

    public String getDataImage() {
        return dataImage;
    }
    public String getDataEndDate() {
        return dateEnd;
    }
    public String getMinGoal() {
        return MinGoal;
    }

    public String getMaxGoal() {
        return MaxGoal;
    }

    public String getTaskName() {
        return TaskName;
    }

    public Dataclass(String dataTitle, String dataDesc, String dataLang, String dataImage,String EndDate,String minGoal, String maxGoal, String taskName) {
        this.dataTitle = dataTitle;
        this.dataDesc = dataDesc;
        this.dataLang = dataLang;
        this.dataImage = dataImage;
        this.dateEnd=EndDate;
        MinGoal = minGoal;
        MaxGoal = maxGoal;
        TaskName = taskName;

    }
    public Dataclass(){}
}
