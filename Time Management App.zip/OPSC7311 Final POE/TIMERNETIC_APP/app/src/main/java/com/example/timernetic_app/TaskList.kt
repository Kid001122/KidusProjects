package com.example.timernetic_app

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.SearchView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.database.*
import java.util.*

class TaskList : AppCompatActivity() {
    var back: Button? = null
    var recyclerView: RecyclerView? = null
    var dataList: List<Dataclass>? = null
    var databaseReference: DatabaseReference? = null
    var eventListener: ValueEventListener? = null

    var searchView: SearchView? = null
    var adapter: MyAdapter? = null
    fun searchList(text: String) {
        val searchList = java.util.ArrayList<Dataclass>()
        for (dataclass in dataList as ArrayList<Dataclass>) {
            if (dataclass.dataTitle.toLowerCase()
                    .contains(text.lowercase(Locale.getDefault()))
            ) {
                searchList.add(dataclass)
            }
        }
        adapter!!.searchDataList(searchList)
    }
    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_task_list)
        back = findViewById(R.id.backtomenu4);
        back?.setOnClickListener {
            startActivity(Intent(this, MainActivity::class.java))
            finish()
        }
        recyclerView = findViewById(R.id.recyclerView)
        val gridLayoutManager = GridLayoutManager(this@TaskList, 1)
        recyclerView?.setLayoutManager(gridLayoutManager)
        searchView = findViewById(R.id.search)
        searchView?.clearFocus()
        val builder = AlertDialog.Builder(this@TaskList)
        builder.setCancelable(false)
        builder.setView(R.layout.progress_layout)
        val dialog = builder.create()
        dialog.show()
        dataList = ArrayList()
         adapter = MyAdapter(this@TaskList, dataList)
        recyclerView?.setAdapter(adapter)

        databaseReference = FirebaseDatabase.getInstance().getReference("Android Tutorials")
        dialog.show()
        eventListener = databaseReference!!.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                (dataList as ArrayList<Dataclass>).clear()
                for (itemSnapshot in snapshot.children) {
                    val dataclass = itemSnapshot.getValue(Dataclass::class.java)
                    (dataList as ArrayList<Dataclass>).add(dataclass!!)
                }
                adapter?.notifyDataSetChanged()
                dialog.dismiss()
            }

            override fun onCancelled(error: DatabaseError) {
                dialog.dismiss()
            }
        })
        searchView?.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String): Boolean {
                return false
            }

            override fun onQueryTextChange(newText: String): Boolean {
                searchList(newText)
                return true
            }
        })




    }

}