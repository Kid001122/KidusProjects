package com.example.timernetic_app

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        var next: Button? = null
        var task: Button? = null
        var timer: Button? = null
        var hangs: Button? = null
        var Calen: Button? = null
        var logout: Button? = null
        var hours: Button? = null
        var Sum: Button? = null
        next = findViewById(R.id.CategoryBtn);
        task = findViewById(R.id.TaskBtn);
        timer = findViewById(R.id.Timerbtn);
        hangs = findViewById(R.id.Hanger);
        Calen = findViewById(R.id.Calendermove);
        hours = findViewById(R.id.total);
        logout=findViewById(R.id.Logoutbtn)
        Sum=findViewById(R.id.Summary)
        hours.setOnClickListener {
            startActivity(Intent(this, Total::class.java))
            finish()
        }
        next.setOnClickListener {
            startActivity(Intent(this, CategoryCreate::class.java))
            finish()
        }
        task.setOnClickListener {
            startActivity(Intent(this,TaskList::class.java))
            finish()
        }
        timer.setOnClickListener {
            startActivity(Intent(this,ClockTimer::class.java))
            finish()
        }
        hangs.setOnClickListener {
            startActivity(Intent(this,Hangman::class.java))
            finish()
        }
        Calen.setOnClickListener {
            startActivity(Intent(this,Calender::class.java))
            finish()
        }
        logout.setOnClickListener {
            startActivity(Intent(this,Login::class.java))
            finish()
        }
        Sum.setOnClickListener {
            startActivity(Intent(this,Summary::class.java))
            finish()
        }
    }
}