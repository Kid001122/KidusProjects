package com.example.timernetic_app

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.storage.FirebaseStorage

class Detail_Activity2 : AppCompatActivity() {
    var detailDesc: TextView? = null
    var detailTitle:TextView? = null
    var detailLang:TextView? = null
    var detailImage: ImageView? = null
    var deleteButton: com.github.clans.fab.FloatingActionButton? = null
    var editButton:com.github.clans.fab.FloatingActionButton? = null
    var key = ""
    var imageUrl = ""
    var exit: Button? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail2)
        detailDesc = findViewById(R.id.detailDesc)
        detailImage = findViewById(R.id.detailImage)
        detailTitle = findViewById(R.id.detailTitle)
        deleteButton = findViewById(R.id.deleteButton)
        editButton = findViewById(R.id.editButton)
        exit = findViewById(R.id.backtomenu6);
        exit?.setOnClickListener {
            startActivity(Intent(this, MainActivity::class.java))
            finish()
        }

        val bundle = intent.extras
        if (bundle != null) {
            detailDesc?.setText(bundle.getString("Description"))
            detailTitle?.setText(bundle.getString("Title"))
            detailLang?.setText(bundle.getString("Language"))
            //key = bundle.getString("key")!!
            imageUrl = bundle.getString("Image")!!
            Glide.with(this).load(bundle.getString("Image")).into(detailImage!!)
        }
        deleteButton?.setOnClickListener(View.OnClickListener {
            val reference = FirebaseDatabase.getInstance().getReference("Android Tutorials")
            val storage = FirebaseStorage.getInstance()
            val storageReference = storage.getReferenceFromUrl(imageUrl)
            storageReference.delete().addOnSuccessListener {
                reference.child(key).removeValue()
                Toast.makeText(this@Detail_Activity2, "Deleted", Toast.LENGTH_SHORT).show()
                startActivity(Intent(applicationContext, MainActivity::class.java))
                finish()
            }
        })

    }
}