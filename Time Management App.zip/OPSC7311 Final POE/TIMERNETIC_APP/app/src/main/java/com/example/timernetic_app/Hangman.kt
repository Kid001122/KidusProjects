package com.example.timernetic_app

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.CountDownTimer
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.os.Handler
import android.widget.Toast
import java.util.Random

class Hangman : AppCompatActivity() {
    private val words = arrayOf("Study", "Exercise", "Cook")
    private val hints = arrayOf("Books", "Fitness", "Food")
    private lateinit var wordToGuess: String
    private lateinit var hiddenWord: CharArray
    private lateinit var guessedLetters: ArrayList<Char>
    private lateinit var attemptsTextView: TextView
    private lateinit var guessEditText: EditText
    private lateinit var submitButton: Button
    private lateinit var hintButton: Button
    private lateinit var wordTextView: TextView
    private lateinit var timerTextView: TextView
    private lateinit var countDownTimer: CountDownTimer
    private var hintWord: String = ""
    private var hintUsed: Boolean = false
    private var score: Int = 0
    private var attemptsLeft = 6
    private var timeLeftInMillis: Long = 60000 // 1 minute
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_hangman)
        var back: Button? = null
        attemptsTextView = findViewById(R.id.attemptsTextView)
        guessEditText = findViewById(R.id.guessEditText)
        submitButton = findViewById(R.id.submitButton)
        wordTextView = findViewById(R.id.wordTextView)
        hintButton = findViewById(R.id.hintButton)
        timerTextView = findViewById(R.id.timerTextView)
        back = findViewById(R.id.backtomenu2);

        back.setOnClickListener {
            startActivity(Intent(this, MainActivity::class.java))
            finish()
        }
        hintButton.setOnClickListener {
            showHint()
        }

        submitButton.setOnClickListener {
            val guessedLetter = guessEditText.text.toString().trim().lowercase()
            if (guessedLetter.length == 1 && guessedLetter[0].isLetter()) {
                handleGuess(guessedLetter[0])
            }
            guessEditText.text.clear()
        }

        val playAgainButton = findViewById<Button>(R.id.playAgainButton)
        playAgainButton.setOnClickListener {
            startNewGame()
            submitButton.isEnabled = true
        }

        startNewGame()
        startTimer()
    }

    private fun showHint() {
        if (!hintUsed) {
            hintUsed = true
            val hintMessage = "Hint: $hintWord"
            val hintDuration = 5000 // 5 seconds
            val toast = Toast.makeText(this, hintMessage, Toast.LENGTH_SHORT)
            toast.show()

            val handler = Handler()
            handler.postDelayed({
                toast.cancel()
            }, hintDuration.toLong())
        }
    }

    private fun startNewGame() {
        val playAgainButton = findViewById<Button>(R.id.playAgainButton)
        playAgainButton.visibility = View.GONE
        val randomIndex = Random().nextInt(words.size)
        wordToGuess = words[randomIndex]
        hintWord = hints[randomIndex]
        wordTextView = findViewById(R.id.wordTextView)
        hiddenWord = CharArray(wordToGuess.length) { '_' }
        guessedLetters = ArrayList()
        attemptsLeft = 4

        updateDisplay()
    }

    private fun handleGuess(letter: Char) {
        if (guessedLetters.contains(letter)) {
            // Letter has already been guessed
            return
        }

        guessedLetters.add(letter)

        if (wordToGuess.contains(letter, ignoreCase = true)) {
            for (i in wordToGuess.indices) {
                if (wordToGuess[i].equals(letter, ignoreCase = true)) {
                    hiddenWord[i] = wordToGuess[i]
                }
            }

            if (!hiddenWord.contains('_')) {
                // All letters have been guessed
                showResult(true)
            }
        } else {
            attemptsLeft--

            if (attemptsLeft == 0) {
                // No more attempts left
                showResult(false)
            }
        }

        updateDisplay()
    }

    private fun updateDisplay() {
        wordTextView.text = hiddenWord.joinToString(" ")
        attemptsTextView.text = getString(R.string.attempts_left, attemptsLeft.toString())
    }

    private fun showResult(isWin: Boolean) {
        val resultTextView = findViewById<TextView>(R.id.resultTextView)
        val scoreTextView = findViewById<TextView>(R.id.scoreTextView)
        if (isWin) {
            score++
            resultTextView.text = getString(R.string.win_message)
        } else {
            resultTextView.text = getString(R.string.lose_message, wordToGuess)
        }
        submitButton.isEnabled = false

        scoreTextView.text = getString(R.string.score_label, score.toString())
        val playAgainButton = findViewById<Button>(R.id.playAgainButton)
        playAgainButton.visibility = View.VISIBLE
        countDownTimer.cancel()
    }

    private fun startTimer() {
        countDownTimer = object : CountDownTimer(timeLeftInMillis, 1000) {
            override fun onTick(millisUntilFinished: Long) {
                timeLeftInMillis = millisUntilFinished
                updateTimer()
            }

            override fun onFinish() {
                showResult(false)
            }
        }.start()
    }

    private fun updateTimer() {
        val minutes = (timeLeftInMillis / 1000) / 60
        val seconds = (timeLeftInMillis / 1000) % 60
        val timeLeftFormatted = String.format("%02d:%02d", minutes, seconds)
        timerTextView.text = timeLeftFormatted
    }
}
class Snake {
    private val body: MutableList<Pair<Int, Int>> = mutableListOf()
    private var direction: Direction = Direction.RIGHT

    fun move() {
        val head = getNextHeadPosition()
        body.add(0, head)
        body.removeAt(body.size - 1)
    }

    fun changeDirection(newDirection: Direction) {
        // Prevent the snake from reversing its direction
        if (direction.isOpposite(newDirection)) return

        direction = newDirection
    }

    private fun getNextHeadPosition(): Pair<Int, Int> {
        val (x, y) = body.first()

        return when (direction) {
            Direction.UP -> Pair(x, y - 1)
            Direction.DOWN -> Pair(x, y + 1)
            Direction.LEFT -> Pair(x - 1, y)
            Direction.RIGHT -> Pair(x + 1, y)
        }
    }

    enum class Direction {
        UP, DOWN, LEFT, RIGHT;

        fun isOpposite(other: Direction): Boolean {
            return (this == UP && other == DOWN) ||
                    (this == DOWN && other == UP) ||
                    (this == LEFT && other == RIGHT) ||
                    (this == RIGHT && other == LEFT)
        }
    }
}
