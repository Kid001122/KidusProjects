package com.example.timernetic_app

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.github.mikephil.charting.charts.BarChart
import com.github.mikephil.charting.charts.PieChart
import com.github.mikephil.charting.data.*
import com.github.mikephil.charting.utils.ColorTemplate

class Summary : AppCompatActivity() {
    var barchart: BarChart? = null
    var pieChart: PieChart? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_summary)
        //barchart = findViewById(R.id.bar_Chart)
        pieChart = findViewById(R.id.pie_chart)
        val pieEntries = mutableListOf<PieEntry>()

        for (i in 1..4) {
            val value = (i * 4).toFloat()
            val pieEntry = PieEntry(value, i.toFloat()) // Corrected the order of value and label
            pieEntries.add(pieEntry)
        }

        val pieDataSet = PieDataSet(pieEntries, "Goals")
        pieDataSet.setColors(*ColorTemplate.JOYFUL_COLORS)
        val pieData = PieData(pieDataSet) // Created a new PieData instance
        pieChart!!.data = pieData // Set the pie data to the pie chart
        pieChart!!.animateXY(5000, 5000)
        pieChart!!.description.isEnabled = true //
    }
}