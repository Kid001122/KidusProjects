package com.example.timernetic_app

import android.app.AlertDialog
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.Toast
import androidx.activity.result.ActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.storage.FirebaseStorage

class CategoryCreate : AppCompatActivity() {
    var uploadImage: ImageView? = null
    var saveBut: Button? = null
    var Backbutton: Button? = null
    var uploadTopic: EditText? = null
    var uploadDesc: EditText? = null
    var uploadLang: EditText? = null
    var uploadEnd: EditText? = null
    var uploadmin: EditText? = null
    var uploadmax: EditText? = null
    var uploadTask: EditText? = null
    var imageURL: String? = null
    var uri: Uri? = null
    fun saveData() {
        val SR = FirebaseStorage.getInstance().reference.child("Android Images")
            .child(uri?.lastPathSegment!!)

        val builder = AlertDialog.Builder(this@CategoryCreate)
        builder.setCancelable(false)
        builder.setView(R.layout.progress_layout)
        val dialog = builder.create()
        dialog.show()

        SR.putFile(uri!!).addOnSuccessListener { taskSnapshot ->
            val uriTask = taskSnapshot.storage.downloadUrl
            while (!uriTask.isComplete);
            val urlImage = uriTask.result
            imageURL = urlImage.toString()
            upload()
            dialog.dismiss()
        }.addOnFailureListener { dialog.dismiss() }
    }
    fun upload() {
        val title = uploadTopic?.text.toString()
        val desc = uploadDesc?.text.toString()
        val lang = uploadLang?.text.toString()
        val Enddate = uploadEnd?.text.toString()
        val task = uploadTask?.text.toString()
        val MIN = uploadmin?.text.toString()
        val Max = uploadmax?.text.toString()

        val dataclass = Dataclass(title, desc, lang, imageURL,Enddate,MIN,Max,task)

        FirebaseDatabase.getInstance().getReference("Android Tutorials").child(title)
            .setValue(dataclass).addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    Toast.makeText(this@CategoryCreate, "Saved", Toast.LENGTH_SHORT).show()
                    startActivity(Intent(this, TaskList::class.java))
                    finish()
                }

            }.addOnFailureListener { e ->
                Toast.makeText(
                    this@CategoryCreate,
                    e.message.toString(),
                    Toast.LENGTH_SHORT
                ).show()
            }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_category_create)
        uploadImage = findViewById(R.id.upload)
        uploadDesc = findViewById(R.id.uploadDesc)
        uploadTopic = findViewById(R.id.uploadTopic)
        uploadLang = findViewById(R.id.uploadLang)
        uploadEnd = findViewById(R.id.uploadEndDate)
        saveBut = findViewById(R.id.saveButton)
        uploadTask = findViewById<EditText>(R.id.uploadTaskName)
        uploadmax = findViewById(R.id.uploadMaxgoal)
        uploadmin = findViewById(R.id.uploadMingoal)
        Backbutton = findViewById(R.id.backbtn)



        val ARL = registerForActivityResult<Intent, ActivityResult>(
            ActivityResultContracts.StartActivityForResult()
        ) { result ->
            if (result.resultCode == RESULT_OK) {
                val data = result.data
                uri = data!!.data
                uploadImage?.setImageURI(uri)
            } else {
                Toast.makeText(this@CategoryCreate, "No image selected", Toast.LENGTH_SHORT)
                    .show()
            }
        }
        Backbutton?.setOnClickListener {
            startActivity(Intent(this, MainActivity::class.java))
            finish()
        }
        uploadImage?.setOnClickListener(View.OnClickListener {
            val phonePicker = Intent(Intent.ACTION_PICK)
            phonePicker.type = "image/*"
            ARL.launch(phonePicker)
        })

        saveBut?.setOnClickListener(View.OnClickListener { saveData() })
    }


}