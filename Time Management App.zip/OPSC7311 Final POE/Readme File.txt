               
ST10090370 Kidus Mekonnen
St10090453 Carlos Ries
ST10090287 Jared Kisten
ST10090431 Vidaal Basha 
ST10090225 Avelino Raposo

# Timer_netic App

Welcome to Timer_netic, an application designed to help you track your time, manage tasks, and stay organized. This app is developed by [Creator Name] and [Co-Creator Name].

## Splash Screen

Upon launching the app, you will be greeted with an animated image that welcomes you to Timer_netic. The splash screen will display the app's name and the names of its creators, providing a warm introduction.

## Registration

To use the Timer_netic app, you need to register an account. The registration process requires the following information:
- Name
- Surname
- Cellphone
- Email
- Password

Once you have filled in all the necessary details, you can press the registration button to save your information. All the provided details will be stored securely in a database for future use within the application.

## Login

After registration, you can access the app by entering your registered name and password on the login page. Once you have filled in the correct details, you can press the login button to gain access to the application. If you are a new user, there is an option to register, which will take you to the registration page.

## Homepage / Navigation

The homepage serves as a central hub for navigating through the app. From here, you can access various features and sections, including:

- Category Page: Create and manage categories along with tasks to organize your activities.
- Create Task Page: Create specific tasks within categories, defining details such as task name, description, start date, end date, minimum goal, maximum goal, and even upload an image from your gallery.
- View Time Sheet Page: Access and view time sheet entries, which allow you to track and manage the time spent on different tasks. A search function is available for easy navigation through the entries.
- View Reports Page: Generate and view reports based on your time sheet data, providing valuable insights into your productivity and time allocation.
- Kill Time Page: Engage in activities to pass the time or take a break from work. Various options will be available to entertain and relax you.
- Get Rewards Page: Explore rewards and incentives to motivate yourself and celebrate your achievements.

OWN FEATURES 
- Events Calender 
- Hangman Game

## Timer

The Timer page allows you to set timers for specific tasks. You can start, stop, and reset timers to track the time you spend on a particular activity. This feature helps you stay focused and manage your time effectively.

## Summary

The Summary page provides a comprehensive overview of the total hours spent on tasks within different categories. This data is displayed in a graph format, enabling you to visualize and analyze your time allocation across various activities.

## Gamification

The Gamification page offers a fun and engaging hangman game. You have 60 seconds to guess a word, and hints are available to assist you in finding the correct answer. This feature adds an element of entertainment and enjoyment to your experience.

## Hours Spent

On the Hours Spent page, you can view the total hours spent on all tasks. The system automatically calculates the cumulative hours from all time sheet entries and displays the total for your reference.

## Event Calendar

The Event Calendar feature allows you to schedule and save events on specific dates. By selecting a date on the calendar, you can set reminders and notes, ensuring that you never miss an important appointment or task.

## Running the App

To run the Timer_netic app on your Android device or emulator, follow these steps:

### Prerequisites

- Install Android Studio: Download and install the latest version of Android Studio from the official website (https://developer.android.com/studio).
- Create a Firebase project: Go to the Firebase Console (

https://console.firebase.google.com/) and create a new project. Note down the project ID as it will be used later.

### Clone the Repository

1. Open Android Studio and choose "Get from Version Control" on the welcome screen.
2. Paste the repository URL (e.g., https://github.com/your-username/Timer_netic.git) and choose a directory to clone the project.
3. Click "Clone" to download the project files from the repository.

### Connect the App to Firebase

1. Open the Firebase Console (https://console.firebase.google.com/).
2. Select your project and click on "Add an app" to register the Timer_netic app with Firebase.
3. Follow the instructions to add the Android package name (e.g., com.example.timer_netic) and app nickname.
4. Download the `google-services.json` file and place it in the "app" directory of the Timer_netic project.

### Set Up Firebase Authentication

1. In the Firebase Console, navigate to the "Authentication" section.
2. Click on "Set up sign-in method" and enable the desired authentication methods (e.g., Email/Password).
3. Configure the selected authentication method(s) following the provided instructions.

### Configure Firebase Realtime Database

1. In the Firebase Console, navigate to the "Database" section.
2. Choose the Realtime Database and set the rules to allow read and write access to authenticated users.

### Run the App

1. Open the Timer_netic project in Android Studio.
2. Wait for the project to sync and build successfully.
3. Connect an Android device or emulator to your computer.
4. Select the device/emulator from the device dropdown menu in the toolbar.
5. Click on the "Run" button to launch the app on the selected device/emulator.
6. Android Studio will build and install the app on the device/emulator, and the Timer_netic app will start running.

Note: Make sure you have the necessary SDK versions and dependencies installed in Android Studio to avoid any build errors.

---

Feel free to customize and enhance the README file further based on your specific implementation and requirements.